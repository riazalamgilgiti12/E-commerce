const express = require('express');
const cors = require('cors');
// const multer = require('multer');

const bodyParser = require('body-parser');

require('./db/config');

const Users = require('./db/Users');
const Product = require('./db/Product');
const profile = require('./demo/profile');
const app = express();
// const Jwt = require('jsonwebtoken');
// const jwtKey = "e-comm";

app.use(express.json());
app.use(cors());



app.post("/register",async (req,resp)=>{
    
    let User1 = new Users(req.body);
    let result = await User1.save();
    result = result.toObject();
    delete result.password
    // Jwt.sign({result},jwtKey,{expiresIn:'1h'},(err,token)=>{
    //     if(err){
    //         resp.send('please try again');
    //     }
    //     resp.send({result,auth:token})}
    
})
app.post('/add-product',async(req,resp)=>{
    let product = new Product(req.body);
    let result = await product.save();
    resp.send(result);
})
app.get('/products',async(req,resp)=>{
let product = await Product.find();
if(product.length>0){
    resp.send(product)
}else{
    resp.send('not foun')
}
})
// we want to delete product
app.delete('/product/:id',async(req,resp)=>{
const result = await Product.deleteOne({_id:req.params.id});
resp.send(result);
})

// want update
app.get ('/product/:id',async(req,resp)=>{
    let result = await Product.findOne({_id:req.params.id});
    if(result){
        resp.send(result)
    }else{
        resp.send("not found ")
    }
})
// update and save
app.put('/product/:id',async(req,resp)=>{
    let result = await Product.updateOne({_id:req.params.id},{$set:req.body})
    resp.send(result)
})
app.get('/search/:key' ,async(req,resp)=>{
    let result = await Product.find({
        "$or":[
            {name:{$regex:req.params.key}},
            {company:{$regex:req.params.key}},
            {category:{$regex:req.params.key}},
            {price:{$regex:req.params.key}},
        ]
    })
    resp.send(result);
})
app.post('/login',async(req,resp)=>{
   
    if(req.body.password && req.body.email){
        let user = await Users.findOne(req.body).select('-password');
        if(user){
          
            resp.send(user);
        }
    }else{
        resp.send({result:"not found"})
    }
    

})
// function verifyToken (req,resp,next){
//     let token = req.headers['Authorization'];
//     if(token){
//         token = token.split(``);
//         Jwt.verify(token,jwtKey,(err,valid)=>{
//             if(err){
//                 resp.send('please valid')
//             }else{
//                 next();
//             }
//         })
//     }else{
//         resp.send('please valid token and header')
//     }
  
// }
// const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//       cb(null, './uploads/'); // Store uploaded images in the "uploads" directory
//     },
//     filename: (req, file, cb) => {
//       cb(null, Date.now() + '-' + file.originalname); // Rename the file to include a timestamp
//     },
//   });
  
//   const upload = multer({ storage });
  



app.listen(5000);