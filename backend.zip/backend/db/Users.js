const mongoose = require('mongoose');
const userSchema = new mongoose.Schema({
    name:String,
    email:String,
    phoneno:Number,
    password:String,
    select:String

    
});
module.exports = mongoose.model("users",userSchema);